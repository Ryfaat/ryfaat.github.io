
// Saat user klik kanan > "Stabilokan"
// nanti info ini akan dikirim ke content
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "stabilokan") {
        chrome.storage.local.get("lastSelectedGroup").then((data) => {
            const selectedGroup = data.lastSelectedGroup || "Ungrouped";
            chrome.tabs.sendMessage(tab.id, {
                command: "highlight",
                color: "yellow",
                groupName: selectedGroup
            });
        });
    }
});


// Buat menu klik kanan saat extension sudah terinstall
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get('contextMenuCreated').then(data => {
        if (!data.contextMenuCreated) {
            chrome.contextMenus.create({
                id: "stabilokan",
                title: "Stabilokan",
                contexts: ["selection"]
            });
            chrome.storage.local.set({ contextMenuCreated: true });
        }
    });
});