function getNodeXPath(node) {
    if (!node || node.nodeType === Node.DOCUMENT_NODE) {
        return ''; 
    }

    let segment = '';
    let index = 1;
    const nodeName = node.nodeName.toLowerCase();
    let sibling = node.previousSibling;

    if (node.nodeType === Node.ELEMENT_NODE) {
        segment = nodeName;
        while (sibling) {
            if (sibling.nodeType === Node.ELEMENT_NODE && sibling.nodeName.toLowerCase() === nodeName) {
                index++;
            }
            sibling = sibling.previousSibling;
        }
        let count = 0;
        if (node.parentNode) {
            for (let i = 0; i < node.parentNode.childNodes.length; i++) {
                const child = node.parentNode.childNodes[i];
                if (child.nodeType === Node.ELEMENT_NODE && child.nodeName.toLowerCase() === nodeName) {
                    count++;
                }
            }
        }
        if (count > 1) {
            segment += `[${index}]`;
        }

    } else if (node.nodeType === Node.TEXT_NODE) {
        segment = 'text()';
        while (sibling) {
            if (sibling.nodeType === Node.TEXT_NODE) {
                index++;
            }
            sibling = sibling.previousSibling;
        }
        let count = 0;
        if (node.parentNode) {
            for (let i = 0; i < node.parentNode.childNodes.length; i++) {
                const child = node.parentNode.childNodes[i];
                if (child.nodeType === Node.TEXT_NODE) {
                    count++;
                }
            }
        }
        if (count > 1) {
            segment += `[${index}]`;
        }

    } else {
        return getNodeXPath(node.parentNode);
    }

    const parentPath = getNodeXPath(node.parentNode);

    if (parentPath === '') {
        return '/' + segment; 
    } else {
        return parentPath + '/' + segment;
    }
}

function getNodeByXPath(xpath) {
    try {
        const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return result.singleNodeValue;
    } catch (e) {
        console.warn("XPath error:", e);
        return null;
    }
}

//sebelum pake GRUP
function highlightSelection(color = 'yellow', groupName = null) {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) {
        alert("Pilih teks dulu untuk di-highlight.");
        return;
    }

    const range = selection.getRangeAt(0);

    const startNode = range.startContainer;
    const startOffset = range.startOffset;
    const endNode = range.endContainer;
    const endOffset = range.endOffset;
    const selectedText = selection.toString();

    const note = prompt("Catatan untuk highlight ini (opsional):");
    if (note === null) {
        selection.removeAllRanges();
        return;
    }

    const startNodeXPath = getNodeXPath(startNode);
    const endNodeXPath = getNodeXPath(endNode);

    if (!startNodeXPath || !endNodeXPath) {
        console.error("Could not generate XPath for selection boundaries. Highlight not saved.");
        alert("Gagal mendapatkan lokasi highlight. Coba pilih area lain.");
        selection.removeAllRanges();
        return;
    }

    selection.removeAllRanges();

    const highlightSpan = document.createElement("span");
    highlightSpan.style.backgroundColor = color;
    highlightSpan.className = "web-highlight";
    highlightSpan.setAttribute("data-highlighted", "true");
    if (note) highlightSpan.setAttribute("title", note);

    const uniqueId = "stabilo-" + Date.now() + "-" + Math.floor(Math.random() * 1000);
    highlightSpan.setAttribute("id", uniqueId);

    const contents = range.extractContents();
    highlightSpan.appendChild(contents);
    range.insertNode(highlightSpan);
    const pageURL = window.location.href;

    chrome.storage.local.get("highlights").then((result) => {
        const highlights = result.highlights || [];
        highlights.push({
            url: pageURL,
            color: color,
            text: selectedText,
            note: note,
            groupName: groupName || null,  // <== Tambahkan grup di sini
            highlightId: uniqueId,
            time: Date.now(),
            startNodeXPath: startNodeXPath,
            startOffset: startOffset,
            endNodeXPath: endNodeXPath,
            endOffset: endOffset
        });
        return chrome.storage.local.set({ highlights });
    }).then(() => {
        console.log("Highlight saved:", {
            id: uniqueId, url: pageURL, text: selectedText, startNodeXPath, startOffset, endNodeXPath, endOffset, group: groupName
        });
    }).catch(error => {
        console.error("Error saving highlight:", error);
        alert("Gagal menyimpan highlight.");
    });
}




function renderStoredHighlights() {
    const currentURL = window.location.href;

    chrome.storage.local.get("highlights").then((result) => {
        const allHighlights = result.highlights || [];
        const pageHighlights = allHighlights.filter(h => h.url === currentURL);

        console.log(`Attempting to render ${pageHighlights.length} highlights for ${currentURL}`);

        pageHighlights.sort((a, b) => {
            if (a.startNodeXPath < b.startNodeXPath) return -1;
            if (a.startNodeXPath > b.startNodeXPath) return 1;
            return a.startOffset - b.startOffset;
        });


        for (const h of pageHighlights) {
            try {
                if (h.highlightId && document.getElementById(h.highlightId)) {
                    continue;
                }
                if (!h.highlightId) {
                    console.warn("Highlight object missing ID:", h);
                    continue;
                }


                const startNode = getNodeByXPath(h.startNodeXPath);
                const endNode = getNodeByXPath(h.endNodeXPath);



                if (!startNode || !endNode) {
                    console.warn("Could not find start or end node for highlight. Skipping rendering:", h.text, h.startNodeXPath, h.endNodeXPath);
                    continue;
                }

                if (!startNode.parentNode || !endNode.parentNode) {
                    console.warn("Start or end node has no parent. Skipping rendering.", h.text);
                    continue;
                }

                const range = document.createRange();
                range.setStart(startNode, h.startOffset);
                range.setEnd(endNode, h.endOffset);

                if (range.collapsed && h.startNodeXPath === h.endNodeXPath && h.startOffset === h.endOffset) {
                    console.warn("Attempted to render a collapsed range. Skipping:", h);
                    continue;
                }


                const highlightSpan = document.createElement("span");
                highlightSpan.style.backgroundColor = h.color || "yellow";
                highlightSpan.className = "web-highlight";
                highlightSpan.setAttribute("data-highlighted", "true");
                highlightSpan.setAttribute("id", h.highlightId);
                if (h.note) highlightSpan.setAttribute("title", h.note);

                const contents = range.extractContents();

                if (!contents) {
                    console.warn("Could not extract contents for range. Skipping rendering step:", h);
                    continue;
                }

                highlightSpan.appendChild(contents);

                range.insertNode(highlightSpan);


            } catch (e) {
                console.error("Error rendering highlight:", h, e);
            }
        }

        const last = pageHighlights[pageHighlights.length - 1];
        if (last && last.highlightId) {
            setTimeout(() => {
                try {
                    const el = document.getElementById(last.highlightId);
                    if (el) {
                        el.scrollIntoView({ behavior: "smooth", block: "center" });
                        el.style.outline = "2px solid orange";
                        setTimeout(() => {
                            el.style.outline = '';
                        }, 1000);
                    } else {
                        console.warn("Element for last highlight ID not found after timeout:", last.highlightId);
                    }
                } catch (scrollError) {
                    console.error("Error during auto-scroll:", scrollError);
                }
            }, 500);
        }

    }).catch(error => {
        console.error("Error retrieving highlights from storage:", error);
    });
}

chrome.runtime.onMessage.addListener((message) => {
    if (message.command === "highlight") {
        highlightSelection(message.color, message.groupName );
        return Promise.resolve(true);
    }
    return false;
});


if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderStoredHighlights);
} else {
    renderStoredHighlights();
}




console.log("Content script loaded and running.");