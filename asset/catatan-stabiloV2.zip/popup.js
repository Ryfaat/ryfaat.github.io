const paletWarna = ['#057F38', '#05387F', '#A109AC', '#777F05', '#8A0002']; // Contoh 5 warna (hijau, biru, oranye, ungu, kuning)

// ini colokan nama
function dapatkanWarnaKonsisten(nama) {
    if (!nama) {
        return paletWarna[0]; // Warna default jika nama kosong
    }
    // Fungsi sederhana untuk menghasilkan hash dari string
    function stringToHash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        return hash;
    }
    const hashNilai = stringToHash(nama);
    const indeksWarna = Math.abs(hashNilai) % paletWarna.length; // Ambil modulus untuk mendapatkan indeks dalam palet
    return paletWarna[indeksWarna];
}

function timeAgo(timestamp) {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return "baru saja";
    if (minutes < 60) return `${minutes} menit lalu`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} jam lalu`;
    const days = Math.floor(hours / 24);
    return `${days} hari lalu`;
}

// Isi dropdown filter kelompok
function populateGroupFilter(highlights) {
    const groupSet = new Set();
    highlights.forEach(h => {
        if (h.groupName) groupSet.add(h.groupName);
    });

    const groupFilter = document.getElementById("groupFilter");
    groupFilter.innerHTML = "";

    const allOption = document.createElement("option");
    allOption.value = "";
    allOption.textContent = "📚 Semua Kelompok";
    groupFilter.appendChild(allOption);

    groupSet.forEach(group => {
        const opt = document.createElement("option");
        opt.value = group;
        opt.textContent = `📁 ${group}`;
        groupFilter.appendChild(opt);
    });

    const newGroupOption = document.createElement("option");
    newGroupOption.value = "__new__";
    newGroupOption.textContent = "➕ Buat Kelompok Baru...";
    groupFilter.appendChild(newGroupOption);
}

chrome.storage.local.get(["highlights", "lastSelectedGroup"]).then((result) => {
    const highlights = result.highlights || [];
    const lastSelected = result.lastSelectedGroup || "";
    const container = document.getElementById("highlightList");
    const groupFilter = document.getElementById("groupFilter");
    
    populateGroupFilter(highlights);

    if ([...groupFilter.options].some(opt => opt.value === lastSelected)) {
        groupFilter.value = lastSelected;
    }

    function renderHighlights(groupName = null) {
        container.innerHTML = "";

        const filtered = groupName
            ? highlights.filter(h => h.groupName === groupName)
            : highlights;

        if (filtered.length === 0) {
            container.innerHTML = `
                <div> Belum ada highlight tersimpan</div>
                <div class="note">Seleksi kalimat > klik Kanan > Stabilokan 📌</div>
            `;
            return;
        }

        filtered.slice().reverse().forEach((item) => {
            const div = document.createElement("div");
            div.className = "highlight-item";
            div.style.cursor = "pointer";

            // potong belakangnya
            const panjangMaksimal = 120;
            let list_stabilo_lengkap = item.text;
            let list_stabilo_pendek = list_stabilo_lengkap.substring(0, panjangMaksimal);
            if (list_stabilo_lengkap.length > panjangMaksimal) {
                list_stabilo_pendek += "...";
            }

            // potong url
            const urlLengkap = item.url;
            const urlObjek = new URL(urlLengkap);
            const hostname = urlObjek.hostname;
            const domainUtama = hostname.replace(/^www\./, '');

            // tambah warna
            const warnaURL = dapatkanWarnaKonsisten(domainUtama);


            // list diisi di sini
            div.innerHTML = `
                <div class="note">${item.note || "(tanpa catatan)"}</div>    
                <div class="highlight-text">"${list_stabilo_pendek}"</div>
                <div class="sub">
                    <div class="link"><span style="color: ${warnaURL}">${domainUtama}</span></div>
                    <button class="delete-btn" style="margin-top:4px">🗑️ Hapus</button>
                </div>
            `;
            //div>📅 ${timeAgo(item.time)}/div>
            // Klik ke halaman highlight
            div.addEventListener("click", (e) => {
                if (!e.target.classList.contains("delete-btn")) {
                    chrome.tabs.create({ url: item.url });
                }
            });

            // Hapus highlight
            div.querySelector(".delete-btn").addEventListener("click", (e) => {
                e.stopPropagation(); // biar gak ikut trigger tab.open
                deleteHighlight(item);
            });

            container.appendChild(div);
        });
    }

    // fungsi hapus
    function deleteHighlight(itemToDelete) {
    const index = highlights.findIndex(h =>
        h.text === itemToDelete.text &&
        h.time === itemToDelete.time &&
        h.url === itemToDelete.url
    );

    if (index !== -1) {
        highlights.splice(index, 1);
        chrome.storage.local.set({ highlights }).then(() => {
            renderHighlights(groupFilter.value || null);
        });
    }
}


    renderHighlights(lastSelected || null);

    groupFilter.addEventListener("change", () => {
        const selected = groupFilter.value;

        if (selected === "__new__") {
            const newGroup = prompt("Nama kelompok baru:");
            if (newGroup) {
                groupFilter.insertBefore(
                    new Option(`📁 ${newGroup}`, newGroup),
                    groupFilter.lastChild
                );
                groupFilter.value = newGroup;
                chrome.storage.local.set({ lastSelectedGroup: newGroup });
                renderHighlights(newGroup);
            } else {
                groupFilter.value = "";
                chrome.storage.local.set({ lastSelectedGroup: "" });
                renderHighlights();
            }
        } else {
            chrome.storage.local.set({ lastSelectedGroup: selected });
            renderHighlights(selected || null);
        }
    });
});





// document.getElementById("highlightBtn").addEventListener("click", () => {
//     const selectedGroup = document.getElementById("groupFilter").value;
//     if (selectedGroup === "__new__") {
//         alert("Silakan buat kelompok baru dulu.");
//         return;
//     }

//     chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
//         chrome.tabs.sendMessage(tabs[0].id, {
//             action: "highlight",
//             groupName: selectedGroup || null
//         });
//     });
// });
